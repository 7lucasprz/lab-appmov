def calculo_y_print(precio, cantidad):
    total = precio * cantidad
    print(f"Se sumaron {total} $")
    return total

def main():
    total_final = 0
    
    while True:
        precio_input = input("Ingrese precio del producto (enter para salir): ")
        
        if precio_input == "":
            break
        
        precio = float(precio_input)
        cantidad = int(input("ingrese cantidad: "))
        
        total_final += calculo_y_print(precio, cantidad)
    
    print(f"Su total es: {total_final} $")

main()