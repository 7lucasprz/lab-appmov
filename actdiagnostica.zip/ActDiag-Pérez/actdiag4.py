pacientes = []

while True:
    print("1. Registrar paciente")
    print("2. Llamar paciente")
    print("3. Salir")

    opcion = input("elija opcion: ")

    if opcion == "1":
        nombre = input("nombre del paciente: ")
        pacientes.append(nombre)

    elif opcion == "2":
        if len(pacientes) > 0:
            paciente = pacientes.pop(0)
            print("pasa:", paciente)
        else:
            print("no hay pacientes")

    elif opcion == "3":
        break

    else:
        print("opcion invalida")