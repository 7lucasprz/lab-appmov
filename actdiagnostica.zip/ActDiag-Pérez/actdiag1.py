clave_correcta = "1234"
intentos = 3

while intentos > 0:
    clave = input("Ingrese la clave: ")
    
    if clave == clave_correcta:
        print("Acceso otorgado")
        break
    else:
        intentos -= 1
        if intentos == 0:
            print("Acceso denegado")
        else:
            print("Vuelva a ingresar la clave")