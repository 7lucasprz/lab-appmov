valores = []

for i in range(10):
    num = float(input("Ingrese un numero: "))
    valores.append(num)

print("1. menor")
print("2. mayor")

opcion = input("elija opcion: ")

if opcion == "1":
    menor = valores[0]
    for num in valores:
        if num < menor:
            menor = num
    print("el menor es:", menor)

elif opcion == "2":
    mayor = valores[0]
    for num in valores:
        if num > mayor:
            mayor = num
    print("el mayor es:", mayor)

else:
    print("opcion invalida")